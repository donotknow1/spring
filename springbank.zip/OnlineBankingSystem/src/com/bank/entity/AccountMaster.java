package com.bank.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class AccountMaster {
	@Id
	 private long accountId;
	  private int accountType;
	  private int accountbalance;
	  private String openingDate;
	public long getAccountId() {
		return accountId;
	}
	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}
	public int getAccountType() {
		return accountType;
	}
	public void setAccountType(int accountType) {
		this.accountType = accountType;
	}
	public int getAccountbalance() {
		return accountbalance;
	}
	public void setAccountbalance(int accountbalance) {
		this.accountbalance = accountbalance;
	}
	public String getOpeningDate() {
		return openingDate;
	}
	public void setOpeningDate(String openingDate) {
		this.openingDate = openingDate;
	}
	  
	  
	  
}
